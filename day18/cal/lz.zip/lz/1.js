/*
    点击按钮的时候：让数量相应的增减

    怎么知道是加法按钮还是减法按钮？
    1.在结构中增加一个自定义属性flag，值1为加法，值0为减法
    2.用dom方法获取所有的加法、减法按钮
    3.根据li下面的第几个孩子button判断加减法按钮
    ...
*/
var btn = document.querySelectorAll(".uls button");
var num = document.querySelectorAll(".uls .num");
for (var i = 0; i < btn.length; i++) {
    btn[i].onclick = function () {
        var flag = this.getAttribute("flag");
        var fjd = this.parentNode;
        var numEl = fjd.querySelector(".num");
        var numValue = Number(numEl.innerText);
        var newValue = 0;
        if (flag == 1) {
            newValue = numValue + 1;
        } else {
            if (numValue < 0) {
                newValue = 0;
                return;
            }
            newValue = numValue - 1;
            // if (numValue > 0) {
            //     newValue = numValue - 1;
            // }
        }
        numEl.innerText = newValue;
    };
}
